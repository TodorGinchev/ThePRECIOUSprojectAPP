package aalto.comnet.thepreciousviewer;


import android.app.Activity;
import android.os.Bundle;

import theprecioussandbox.comnet.aalto.precious.R;


public class About extends Activity {
    /** Called when the activity is first created. */
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);
    }
}