package wearable_test.comnet.aalto.wearable_test;

public interface ActionCallback {
    public void onSuccess(Object data);

    public void onFail(int errorCode, String msg);
}
