package wearable_test.comnet.aalto.wearable_test;


import android.app.Service;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import wearable_test.comnet.aalto.wearable_test.listeners.NotifyListener;
import wearable_test.comnet.aalto.wearable_test.model.VibrationMode;

public class BackgroundService extends Service {

    private static final String TAG = "BackgroundService";
    private MiBand miband;
    public Context mContext;
    private BluetoothDevice device;

    @Override
    public void onCreate() {

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int idArranque) {
        mContext=this;
        Log.i(TAG,"onStartCommand");
        miband = new MiBand(this);
        device = intent.getParcelableExtra("device");
//        final ProgressDialog pd = ProgressDialog.show(BackgroundService.this, "", "Connecting, please wait...");
        Log.i(TAG,"Connecting...");
        miband.connect(device, new ActionCallback() {

            @Override
            public void onSuccess(Object data) {
//                pd.dismiss();
                Log.d(TAG, "Connected!!!");
                miband.startVibration(VibrationMode.VIBRATION_WITH_LED);

                miband.setDisconnectedListener(new NotifyListener() {
                    @Override
                    public void onNotify(byte[] data) {
                        Log.d(TAG, "Disconnected!!!");
                        stopService(new Intent(mContext, BackgroundService.class));
                    }
                });
            }

            @Override
            public void onFail(int errorCode, String msg) {
//                pd.dismiss();
                Log.d(TAG, "connect fail, code:" + errorCode + ",mgs:" + msg);
            }
        });

        return START_NOT_STICKY;
    }


    public void onDestroy()
    {
        Intent intent = new Intent(this,BackgroundService.class);
        intent.putExtra("device", device);
        startService(intent);

    }

    @Override
    public IBinder onBind(Intent intencion) {
        return null;
    }


}
