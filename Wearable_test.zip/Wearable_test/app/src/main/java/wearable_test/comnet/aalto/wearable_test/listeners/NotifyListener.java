package wearable_test.comnet.aalto.wearable_test.listeners;

public interface NotifyListener {
    public void onNotify(byte[] data);
}
