package wearable_test.comnet.aalto.wearable_test.listeners;

public interface RealtimeStepsNotifyListener {
    public void onNotify(int steps);
}
